
let sunY = 100;
let flowers = [];
let birds = [];
let timeOfDay = 0; // 0 a 1, onde 0 = manhã, 0.5 = entardecer, 1 = noite
let cycleSpeed = 0.0005;

function setup() {
    let canvas = createCanvas(800, 500);
    canvas.parent('canvas-container');
    for (let i = 0; i < 20; i++) {
        flowers.push(new Flower(random(width), random(height - 120, height - 40)));
    }
    for (let i = 0; i < 5; i++) {
        birds.push(new Bird(random(width), random(50, 150)));
    }
}

function draw() {
    timeOfDay += cycleSpeed;
    if (timeOfDay > 1) timeOfDay = 0;
    drawSky(timeOfDay);
    drawSunAndMoon(timeOfDay);

    for (let bird of birds) {
        bird.move();
        bird.display();
    }

    fill(120, 200, 100);
    noStroke();
    rect(0, height - 60, width, 60);

    for (let flower of flowers) {
        flower.update(mouseX, mouseY);
        flower.grow();
        flower.display();
    }
}

function drawSky(t) {
    let c1, c2;
    if (t < 0.5) {
        c1 = lerpColor(color('#90caf9'), color('#ffcc80'), t * 2);
        c2 = lerpColor(color('#ffe082'), color('#6d4c41'), t * 2);
    } else {
        c1 = lerpColor(color('#003366'), color('#0b0b33'), (t - 0.5) * 2);
        c2 = lerpColor(color('#001133'), color('#000000'), (t - 0.5) * 2);
    }

    for (let y = 0; y < height; y++) {
        let inter = map(y, 0, height, 0, 1);
        let c = lerpColor(c1, c2, inter);
        stroke(c);
        line(0, y, width, y);
    }
}

function drawSunAndMoon(t) {
    let x = width - 100;
    let y = 100 + 60 * sin(TWO_PI * t);

    if (t < 0.5) {
        noStroke();
        fill(255, 204, 0, 180);
        ellipse(x, y, 40);
    } else {
        noStroke();
        fill(250, 250, 255);
        ellipse(x, y, 40);
        fill(240);
        ellipse(x + 5, y - 5, 8);
        ellipse(x - 5, y + 8, 6);
        ellipse(x + 10, y + 4, 5);
    }
}

function mousePressed() {
    flowers.push(new Flower(mouseX, mouseY));
}

class Flower {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = 0.5;
        this.maxSize = random(1.2, 1.8);
        this.rotation = random(TWO_PI);
        this.rotationSpeed = random(-0.01, 0.01);
        this.hovered = false;
        this.petalColor = color(random(220, 255), random(100, 200), random(200, 255));
        this.centerColor = color(255, 230, 120);
    }

    update(mx, my) {
        this.hovered = dist(mx, my, this.x, this.y) < 25;
        if (this.hovered) {
            this.rotation += this.rotationSpeed * 4;
        } else {
            this.rotation += this.rotationSpeed;
        }
    }

    grow() {
        if (this.size < this.maxSize) {
            this.size += 0.005;
        }
    }

    display() {
        push();
        translate(this.x, this.y);
        scale(this.size);

        stroke(34, 139, 34);
        strokeWeight(3);
        line(0, 0, 0, 30);

        fill(34, 139, 34, 200);
        noStroke();
        ellipse(-6, 10, 12, 25);
        ellipse(6, 15, 12, 25);

        push();
        rotate(this.rotation);
        fill(this.petalColor);
        stroke(255, 200);
        strokeWeight(0.5);
        for (let i = 0; i < 8; i++) {
            let angle = TWO_PI / 8 * i;
            push();
            rotate(angle);
            beginShape();
            vertex(0, 0);
            bezierVertex(6, -20, 16, -20, 12, 0);
            endShape(CLOSE);
            pop();
        }
        pop();

        noStroke();
        fill(this.centerColor);
        ellipse(0, 0, 16);
        fill(255, 255, 255, 30);
        ellipse(3, -2, 3);
        ellipse(-2, 2, 2);
        pop();
    }
}

class Bird {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.speed = random(1, 2);
        this.flap = 0;
    }

    move() {
        this.x += this.speed;
        this.flap += 0.2;
        if (this.x > width + 50) {
            this.x = -50;
            this.y = random(30, 150);
        }
    }

    display() {
        push();
        translate(this.x, this.y);
        noStroke();
        fill(60);
        ellipse(0, 0, 20, 12); // corpo
        fill(80);
        ellipse(-8, -2 + sin(this.flap) * 2, 10, 6); // asa esquerda
        ellipse(8, -2 + sin(this.flap + PI) * 2, 10, 6); // asa direita
        fill(255, 255, 100);
        triangle(10, 0, 14, 2, 14, -2); // bico
        pop();
    }
}
